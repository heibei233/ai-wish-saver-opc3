# OPC3赛题A AI愿望储蓄罐提交包

本提交包围绕赛题A“AI原生储蓄型游戏化APP留存系统”生成，核心方案为“AI愿望储蓄罐”：把用户真实购物意图转化为可持续回流的储蓄任务、随机奖励和兑换下单闭环。

重要说明：赛题要求是设计一套 APP 留存系统并提交高保真可交互原型，不要求开发正式上架的原生 App。本包额外提供“APP演示版.html”，打开后就是可运行的移动端 App 式原型，可用于路演现场演示任务、宝箱、扭蛋、兑换和购物车抵扣闭环。

## 文件清单
- OPC3赛题A_AI愿望储蓄罐_机制设计文档.docx
- OPC3赛题A_AI愿望储蓄罐_视觉规范.docx
- OPC3赛题A_AI愿望储蓄罐_AI应用说明.docx
- OPC3赛题A_AI愿望储蓄罐_OnePager.docx
- OPC3赛题A_AI愿望储蓄罐_APP演示版.html
- OPC3赛题A_AI愿望储蓄罐_交互原型.html
- OPC3赛题A_AI愿望储蓄罐_架构图与工作流.html
- OPC3A_AIWishSaver_RealApp_PWA/：可安装 PWA App 项目，包含 index、JS、CSS、manifest、service worker、图标和启动脚本
- OPC3赛题A_AI愿望储蓄罐.apk：Android 可安装演示包
- OPC3A_AIWishSaver_iOS_PWA/：iPhone Safari 可添加到主屏幕的 iOS PWA 版本
- OPC3A_AIWishSaver_iOS_WKWebView_Source/：iOS 原生 WKWebView 壳源码，可在 Mac + Xcode 中签名打 IPA

## 建议提交/路演顺序
1. 先用 One Pager 讲清楚核心概念和差异化。
2. 打开 APP演示版 HTML，像真实 App 一样演示完成任务、开宝箱、抽扭蛋、兑换奖励和购物车抵扣。
3. 若评委追问“是不是 App”，打开 RealApp_PWA 文件夹里的 start_app.ps1，启动可安装 PWA App，并演示浏览器安装、离线缓存和本地状态保存。
4. Android 手机可直接安装 APK；iPhone 可用 iOS_PWA 版本添加到主屏幕，或在 Mac 上用 WKWebView 源码继续签名导出 IPA。
5. 打开交互原型 HTML，按左侧 16 个页面讲完整用户旅程和页面结构。
6. 用机制设计文档回答评委关于理论、AI原生、数值模型和可落地性的追问。
7. 用视觉规范证明交互和设计输出可继续扩展到 Figma 高保真稿。
8. 用 AI应用说明满足赛事原创性和AI工具使用披露要求。

## 提交前需要替换的信息
- 队名、成员姓名、指导老师、联系方式。
- 如后续使用 Figma / Midjourney / Stable Diffusion 等工具，请把真实使用记录补入 AI应用说明。
- 若需要严格 Figma 文件，可按 HTML 原型的 16 屏结构在 Figma 中复刻并补充动效。
- APP演示版是 Web App 原型，适合现场演示；正式提交如要求 Figma/Axure，可把它作为交互逻辑参考。
- RealApp_PWA 是可运行、可安装、可离线缓存的 PWA 原型；它仍不是正式上架的 iOS/Android 原生包，但已经具备“真实 App 原型”的运行形态。
- iOS 的 IPA 不能在 Windows 直接生成；Apple 要求 macOS + Xcode + 开发者证书签名。本包已提供 iOS PWA 安装版和 Xcode WKWebView 源码，方便有 Mac 时继续打包 IPA。
