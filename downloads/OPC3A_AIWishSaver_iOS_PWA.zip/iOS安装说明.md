# AI愿望储蓄罐 iOS 安装说明

这是 iPhone 可安装的 PWA 版本。它不是 `.ipa`，但在 iPhone 上可以通过 Safari 添加到主屏幕，打开后是独立 App 体验。

## 为什么现在不能直接生成 IPA

iOS 的 `.ipa` 必须使用 macOS + Xcode + Apple Developer 证书签名。当前环境是 Windows，因此不能直接完成 iOS 原生签名打包。  
本文件夹提供的是 iOS Safari 可安装 PWA；另一个 `iOS_WKWebView_Source` 文件夹提供原生 WKWebView 源码，可在 Mac 上继续打包 IPA。

## iPhone 安装方式

1. 将本文件夹部署到任意 HTTPS 静态网站，或在同一局域网启动本地服务器。
2. 用 iPhone Safari 打开 `index.html` 对应的网址。
3. 点击 Safari 分享按钮。
4. 选择“添加到主屏幕”。
5. 桌面出现“愿望储蓄罐”，打开后即为全屏 App 体验。

## 演示路径

1. 首页查看愿望商品、金币、连续天数和抵扣金额。
2. 完成两个任务，解锁宝箱。
3. 进入奖励页，开宝箱、抽愿望扭蛋、兑换 `$8 OFF`。
4. 进入购物车，查看抵扣与预计支付金额变化。
5. 进入增长看板，讲 D7 留存、任务完成率、补贴 ROI 和券核销率。

## 提交建议

路演时可以说：

> Android 侧我们已生成可安装 APK；iOS 侧由于 Apple 签名限制，本轮提供可安装 PWA 与 WKWebView 原生壳源码。若有 Apple 开发者证书，可在 Mac 上打出 IPA。
