$ErrorActionPreference = "Stop"

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 4183
$url = "http://127.0.0.1:$port/"

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
  $python = Get-Command py -ErrorAction SilentlyContinue
}

if (-not $python) {
  Write-Host "未找到 Python。请安装 Python，或用任意静态服务器打开本目录。"
  exit 1
}

$existing = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
if (-not $existing) {
  Start-Process -FilePath $python.Source -ArgumentList @("-m", "http.server", "$port", "--directory", "$appDir") -WindowStyle Hidden
  Start-Sleep -Seconds 1
}

Start-Process $url
Write-Host "iOS PWA 预览已启动：$url"
