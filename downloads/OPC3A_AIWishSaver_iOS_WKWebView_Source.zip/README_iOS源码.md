# AI愿望储蓄罐 iOS WKWebView 源码包

这个文件夹是 iOS 原生壳源码，用 `WKWebView` 加载本地 `WebAssets/index.html`，用于在 macOS + Xcode 环境下打包 `.ipa`。

## 环境要求

- macOS
- Xcode 15 或更新版本
- Apple Developer 账号或本地开发者签名

## 使用方式

1. 在 Mac 上打开 `AIWishSaver.xcodeproj`。
2. 选择 target：`AIWishSaver`。
3. 在 Signing & Capabilities 里选择你的 Team。
4. 修改 Bundle Identifier，例如 `com.yourteam.aiwishsaver`。
5. 连接 iPhone，点击 Run 安装到真机。
6. 若要导出 IPA：Product → Archive → Distribute App。

## 说明

- 当前 Windows 环境不能直接生成 `.ipa`，因为 iOS 签名必须依赖 Xcode 和 Apple 证书。
- Android 侧已经提供可安装 APK；iOS 侧提供 PWA 安装版和原生 WKWebView 源码。
- `WebAssets` 中的 HTML/CSS/JS 与 Android/PWA 原型共用同一套交互逻辑。
