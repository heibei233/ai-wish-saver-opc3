import UIKit
import WebKit

final class WebViewController: UIViewController, WKNavigationDelegate {
    private var webView: WKWebView!

    override func loadView() {
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.bounces = false
        self.webView = webView
        view = webView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        loadBundledApp()
    }

    private func loadBundledApp() {
        guard let indexURL = Bundle.main.url(
            forResource: "index",
            withExtension: "html",
            subdirectory: "WebAssets"
        ) else {
            showMissingAssetError()
            return
        }

        let assetsURL = indexURL.deletingLastPathComponent()
        webView.loadFileURL(indexURL, allowingReadAccessTo: assetsURL)
    }

    private func showMissingAssetError() {
        let html = """
        <html><body style="font-family:-apple-system;padding:24px">
        <h2>Missing WebAssets</h2>
        <p>请确认 index.html、app.js 和 styles.css 已加入 Copy Bundle Resources。</p>
        </body></html>
        """
        webView.loadHTMLString(html, baseURL: nil)
    }
}
